package com.example.smartstock;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class InventoryActivity extends AppCompatActivity {

    private EditText editItemName, editItemQuantity, editReorderLevel;
    private Button buttonAddItem, buttonUpdateItem, buttonSmsSettings;
    private TableLayout tableInventory;
    private TextView textEmptyState;

    private DatabaseHelper databaseHelper;
    private int selectedItemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Connect UI elements from the XML layout
        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);
        editReorderLevel = findViewById(R.id.editReorderLevel);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonUpdateItem = findViewById(R.id.buttonUpdateItem);
        buttonUpdateItem.setEnabled(false);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);
        tableInventory = findViewById(R.id.tableInventory);
        textEmptyState = findViewById(R.id.textEmptyState);

        // Create database helper
        databaseHelper = new DatabaseHelper(this);

        // Load inventory items when the screen opens
        loadInventoryTable();

        // Add a new inventory item
        buttonAddItem.setOnClickListener(v -> {
            String itemName = editItemName.getText().toString().trim();
            String quantityText = editItemQuantity.getText().toString().trim();
            String reorderLevelText = editReorderLevel.getText().toString().trim();

            if (TextUtils.isEmpty(itemName) || TextUtils.isEmpty(quantityText) || TextUtils.isEmpty(reorderLevelText)) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityText);
            int reorderLevel = Integer.parseInt(reorderLevelText);

            long result = databaseHelper.addItem(itemName, quantity, reorderLevel);

            if (result != -1) {
                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
                checkAndSendLowStockAlert(itemName, quantity);
                clearInputFields();
                loadInventoryTable();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        });

        // Update the selected inventory item
        buttonUpdateItem.setOnClickListener(v -> {
            if (selectedItemId == -1) {
                Toast.makeText(this, "Select an item to update", Toast.LENGTH_SHORT).show();
                return;
            }

            String itemName = editItemName.getText().toString().trim();
            String quantityText = editItemQuantity.getText().toString().trim();
            String reorderLevelText = editReorderLevel.getText().toString().trim();

            if (TextUtils.isEmpty(itemName) || TextUtils.isEmpty(quantityText) || TextUtils.isEmpty(reorderLevelText)) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityText);
            int reorderLevel = Integer.parseInt(reorderLevelText);

            boolean updated = databaseHelper.updateItem(selectedItemId, itemName, quantity, reorderLevel);

            if (updated) {
                Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();
                checkAndSendLowStockAlert(itemName, quantity);
                clearInputFields();
                selectedItemId = -1;
                buttonUpdateItem.setEnabled(false);
                loadInventoryTable();
            } else {
                Toast.makeText(this, "Failed to update item", Toast.LENGTH_SHORT).show();
            }
        });

        // Open SMS notification settings
        buttonSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, SmsSettingsActivity.class);
            startActivity(intent);
        });
    }

    private void loadInventoryTable() {
        // Keep the header row and remove previous data rows
        if (tableInventory.getChildCount() > 1) {
            tableInventory.removeViews(1, tableInventory.getChildCount() - 1);
        }

        Cursor cursor = databaseHelper.getAllItems();

        if (cursor.getCount() == 0) {
            textEmptyState.setVisibility(TextView.VISIBLE);
        } else {
            textEmptyState.setVisibility(TextView.GONE);

            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                int reorderLevel = cursor.getInt(cursor.getColumnIndexOrThrow("reorder_level"));

                String status = quantity <= reorderLevel ? "LOW" : "OK";

                TableRow row = new TableRow(this);

                TextView nameView = createCell(itemName);
                TextView quantityView = createCell(String.valueOf(quantity));
                TextView reorderView = createCell(String.valueOf(reorderLevel));
                TextView statusView = createCell(status);

                Button deleteButton = new Button(this);
                deleteButton.setText("Del");
                deleteButton.setPadding(8, 4, 8, 4);
                deleteButton.setOnClickListener(v -> {
                    boolean deleted = databaseHelper.deleteItem(id);
                    if (deleted) {
                        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                        clearInputFields();
                        selectedItemId = -1;
                        buttonUpdateItem.setEnabled(false);
                        loadInventoryTable();
                    } else {
                        Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
                    }
                });

                // Allow the user to tap a row and load it into the input fields for editing
                row.setOnClickListener(v -> {
                    selectedItemId = id;
                    editItemName.setText(itemName);
                    editItemQuantity.setText(String.valueOf(quantity));
                    editReorderLevel.setText(String.valueOf(reorderLevel));
                    buttonUpdateItem.setEnabled(true);
                    Toast.makeText(this, "Item loaded. You can now edit and press Update.", Toast.LENGTH_SHORT).show();
                });

                row.addView(nameView);
                row.addView(quantityView);
                row.addView(reorderView);
                row.addView(statusView);
                row.addView(deleteButton);

                tableInventory.addView(row);
            }
        }

        cursor.close();
    }

    private TextView createCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(16, 16, 16, 16);
        textView.setGravity(Gravity.CENTER);
        return textView;
    }

    private void clearInputFields() {
        editItemName.setText("");
        editItemQuantity.setText("");
        editReorderLevel.setText("");
    }

    private void checkAndSendLowStockAlert(String itemName, int quantity) {
        if (quantity == 0) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(
                        "5554",
                        null,
                        "Alert: Item " + itemName + " is out of stock.",
                        null,
                        null
                );

                Toast.makeText(this, "SMS alert sent", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission not granted. App continues without SMS alerts.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}