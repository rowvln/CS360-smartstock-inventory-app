package com.example.smartstock;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsSettingsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private Button buttonEnableSms;
    private Button buttonBackToInventory;
    private TextView textPermissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_settings);

        buttonEnableSms = findViewById(R.id.buttonEnableSms);
        buttonBackToInventory = findViewById(R.id.buttonBackToInventory);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);

        updatePermissionStatus();

        buttonEnableSms.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{android.Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE
                );

            } else {
                textPermissionStatus.setText("Granted");
                Toast.makeText(this, "SMS notifications are already enabled", Toast.LENGTH_SHORT).show();
            }
        });

        buttonBackToInventory.setOnClickListener(v -> finish());
    }

    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            textPermissionStatus.setText("Granted");
        } else {
            textPermissionStatus.setText("Not Granted");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                textPermissionStatus.setText("Granted");
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                textPermissionStatus.setText("Denied");
                Toast.makeText(this, "SMS permission denied. The app will continue without SMS alerts.", Toast.LENGTH_LONG).show();
            }
        }
    }
}